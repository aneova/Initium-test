import {Component, Input, input, OnInit} from '@angular/core';
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
import {RecordService} from "../../services/data.service";

@Component({
  selector: 'app-delete-modal',
  standalone: true,
  imports: [],
  templateUrl: './delete-modal.component.html',
  styleUrl: './delete-modal.component.css'
})

export class DeleteModalComponent implements OnInit{
  constructor(public activeModal: NgbActiveModal, public dataService: RecordService) {}

  @Input() public toBeDeleted: number[]=[];
  ngOnInit() {
   console.log(this.toBeDeleted)
  }

  delete() {
    console.log(this.toBeDeleted)
    for (let i=0; i<this.toBeDeleted.length; i++)
    {
        const index = this.dataService.phoneBook.indexOf(this.dataService.phoneBook[this.toBeDeleted[i]])
        this.dataService.phoneBook.splice(index, 1);
    }
    console.log(this.dataService.phoneBook)
    this.toBeDeleted = [];
    this.activeModal.close();
  }
  dismiss() {
    this.toBeDeleted = [];
    this.activeModal.close();
  }
}
