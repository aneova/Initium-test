import {Component, Input, OnInit} from '@angular/core';
import {AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
import {CommonModule, NgIf} from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {PhoneRecord, RecordService} from "../services/data.service";
import {PhoneMaskDirective} from "../utils/phone-mask.directive";

@Component({
  selector: 'app-modal',
  standalone: true,
  imports: [CommonModule,  ReactiveFormsModule, PhoneMaskDirective],
  templateUrl: './modal.component.html',
  styleUrl: './modal.component.css'
})

//public form!: FormGroup;
export class ModalComponent implements OnInit {
  constructor(private formBuilder: FormBuilder, public dataService: RecordService) {}
  form: FormGroup = new FormGroup({
    name: new FormControl(''),
    surname: new FormControl(''),
    email: new FormControl(''),
    phone: new FormControl('')
  });
  @Input() public recordId!: PhoneRecord;
  @Input() public Id!: number;
  ngOnInit() {
    console.log(this.Id, this.recordId)
    // @ts-ignore
    this.form = this.formBuilder.group(
      {
        name: ['', [Validators.required,
                   Validators.minLength(2)]],
        surname: [
          '',
          [
            Validators.required,
            Validators.minLength(2)
          ],
        ],
        email: [null, [Validators.required, Validators.email]],
        phone: [
          '',
          [
            Validators.required,
            Validators.minLength(12)
          ],
        ],
      },
    );
    this.fillForm(this.recordId);
  }
  submitted = false;
  fillForm(record:PhoneRecord){
    // @ts-ignore
    this.form.get('phone').setValue(record.phone);
    // @ts-ignore
    this.form.get('email').setValue(record.email);

    // @ts-ignore
    this.form.get('surname').setValue(record.surname);
    // @ts-ignore
    this.form.get('name').setValue(record.name);
  }

  // @ts-ignore
  submit() {
    console.log(this.form.value)
    const newRecord: PhoneRecord = {
      id: this.form?.get('id')?.value,
      email: this.form?.get('email')?.value,
      name: this.form?.get('name')?.value,
      surname: this.form?.get('surname')?.value,
      phone: '+7'+this.form?.get('phone')?.value,
    }
    if(!this.Id) {
      // @ts-ignore

      this.form.markAllAsTouched();
      this.submitted = true;
      this.dataService.phoneBook.push(newRecord);
      console.log(this.dataService.phoneBook);
    } else {
      this.dataService.phoneBook[this.Id] = newRecord;
    }
  }
  // @ts-ignore
  onCancel($event){
    $event.preventDefault();
    this.submitted = false;
    this.form.reset();
  }

  get f(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }
}



