import {Injectable} from "@angular/core";
import {Observable, of} from "rxjs";
import {HttpClient} from "@angular/common/http";

export interface PhoneRecord {
  name: string;
  surname: string;
  phone: string;
  email: string;
  id: number;
}
//public Records:Array<PhoneRecord>;
@Injectable({providedIn: 'root'})
export class RecordService {

 public phoneBook: PhoneRecord[] = [];

  constructor(private http:HttpClient) {
  }

  fetchRecords(): Observable<PhoneRecord[]> {
    // @ts-ignore
    const PhoneRecord = this.http.get<PhoneRecord[]>('https://test-data.directorix.cloud/task1');
      return PhoneRecord;
  }

  addRecord(phoneRecord: PhoneRecord): void  {
    this.phoneBook.push(phoneRecord);
  }

}

