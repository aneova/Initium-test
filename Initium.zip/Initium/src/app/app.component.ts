import {Component, ElementRef, OnInit} from '@angular/core';
import { RouterOutlet } from '@angular/router';
import {PhoneRecord, RecordService} from "./services/data.service";
import {TableModule} from "primeng/table";
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {ModalComponent} from "./modal/modal.component";
import {DeleteModalComponent} from "./utils/delete-modal/delete-modal.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, TableModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  title = 'Initium';

    public Records!: Array<PhoneRecord>;
  constructor(public dataService: RecordService,  public  modalService: NgbModal)  {
  }
 public selected:number[] = [];
  ngOnInit(): void {
      this.dataService.fetchRecords().subscribe((data:any)=>{
      this.Records = data.users;
      this.dataService.phoneBook = data.users;
      console.log(this.dataService.phoneBook);
    })
  }
  open() {
    const modalRef = this.modalService.open(ModalComponent);
    modalRef.componentInstance.recordId = null;
    modalRef.componentInstance.Id = null;
  }

  editUser(id:number){
    // @ts-ignore
    const dialogRef = this.modalService.open(ModalComponent, {recordId: id})
    dialogRef.componentInstance.recordId = this.Records[id];
    dialogRef.componentInstance.Id = id;
    // console.log('APP ',this.Records[id])
  }

  addUser(i: any) {
    console.log(i);
    this.selected.push(i);
  }

  // @ts-ignore
  selectAll() {
    const selectId = document.getElementById('selAll') as HTMLInputElement;
    if(!selectId.checked) {
      this.selected = [];
      selectId.checked = false;
    }
    // @ts-ignore
    let checkboxes = document.querySelectorAll('input[type="checkbox"]') as HTMLInputElement[];
    console.log(checkboxes);
    for (var i = 0; i+1 < checkboxes.length+1; i++) {
      checkboxes[i].checked =selectId.checked;
     this.selected.push(i);
    }
    console.log(this.selected);
  }

  delete() {
    // @ts-ignore
    const modalRef = this.modalService.open(DeleteModalComponent);
    modalRef.componentInstance.toBeDeleted = this.selected;
    this.selected= [];
    const selectId = document.getElementById('selAll') as HTMLInputElement;
    selectId.checked =  !selectId.checked;

    // console.log(this.selected)
  }
}
